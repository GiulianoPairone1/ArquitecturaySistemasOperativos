#!/bin/bash

val="hola"
read -p'Ingrese su usuario' user
read -p 'Ingrese su clave: ' pass 
pass=${pass,,}
if [ $pass -eq $val ];
then
 echo Inicion de sesion correcto!
else
 echo Datos incorrectos
fi
