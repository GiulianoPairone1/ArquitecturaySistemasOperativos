#!/bin/bash

for I in {1..5};
do
  read -p 'Ingrese un numero positivo: ' num
  until [ $num -gt $0 ]
  do
    read -p 'El numero ingresado no es correcto , ingrese nuevamente el un numero: ' num
  done
  if [ $num -gt $mayor ];
  then
    mayor=$num
    fi
  while [ $contador -lt 0 ]
    do
     menor=$num
     contador=$contador+1
    done    
   if [ $num -lt $menor ];
   then
     menor=$num
    fi
done
dif= $mayor-$menor
echo La diferencia entre el numero mayor $mayor y el menor $menor es $dif
