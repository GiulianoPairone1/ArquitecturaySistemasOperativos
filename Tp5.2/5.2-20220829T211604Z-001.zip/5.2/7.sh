#!/bin/bash
I=3
M=4
MB=7
E=10
read -p 'Ingrese su nota: ' nota
#
if [[ $nota -lt $M ]] ;
then
  echo Su nota es Irregular
  fi
if [ $nota -ge $M ] && [ $nota -le $MB ] ;
then
  echo Su nota es Buena
  fi
if [ $nota -gt $MB ] && [ $nota -le $E ];
then
  echo Su nota es Muy Buena
  fi
if [[ $nota -eq $E ]];
then 
  echo Su nota es Excelente
  fi
