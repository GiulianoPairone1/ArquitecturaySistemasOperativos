#!/bin/bash
Sueldo=280000
Impuesto=24
read -p 'Ingrese el valor de su sueldo: ' suel
if [[ $suel -lt $Sueldo ]];
then
  echo No debe aponar impuesto a la ganancia
else
  newsueldo=$((($suel * $Impuesto)/100))
  echo Debe abonar impuesto , ya que su sueldo supera el valor de $ 280000, el valor a pagar es: $newsueldo
  fi
