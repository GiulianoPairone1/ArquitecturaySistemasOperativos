#!/bin/bash
read -p 'Ingrese el primer numero: ' num1
read -p 'Ingrese el segundo numero: ' num2
read -p 'Ingrese el tercer numero: ' num3
read -p 'Ingrese el cuarto numero: ' num4
read -p 'Ingrese el quinto numero: ' num5

prom=$((($num1 + $num2 + $num3 + $num4 + $num5)/5))

echo El promedio es  $prom 
