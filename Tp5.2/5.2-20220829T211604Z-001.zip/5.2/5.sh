#!/bin/bash

read -p 'Ingrese el primer digito de su numero de 2 cifras: ' n
read -p 'Ingrese el segundo digito de su numero de 2 cifras: ' n1

