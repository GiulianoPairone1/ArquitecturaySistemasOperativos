#!/bin/bash
h1=0
echo "$h1"
h2=1
h=0
echo "$h2"
for i in 0 1 2 3 4 5 6 7
do
 h=$(($h1+$h2))
 echo $h
 h1=$h2
 h2=$h
done
